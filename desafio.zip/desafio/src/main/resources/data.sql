INSERT INTO TB_MUSICA(TITULO,ARTISTA,ALBUM,ANO,GENERO) VALUES ('Backslide','Twenty One Pilots','Clancy','2024','PopRock');
INSERT INTO TB_MUSICA(TITULO,ARTISTA,ALBUM,ANO,GENERO) VALUES ('Welcome to the jungle','guns n roses','appetite for destruction','1988','classic rock');
INSERT INTO TB_MUSICA(TITULO,ARTISTA,ALBUM,ANO,GENERO) VALUES ('Smooth Criminal','Michael Jackson','Bad','1988','Pop');
INSERT INTO TB_MUSICA(TITULO,ARTISTA,ALBUM,ANO,GENERO) VALUES ('Billie Jean','Michael Jackson','Thriller','1982','R&B');
INSERT INTO TB_MUSICA(TITULO,ARTISTA,ALBUM,ANO,GENERO) VALUES ('Sweet Child o Mine','Twenty One Pilots','Clancy','2024','PopRock');
